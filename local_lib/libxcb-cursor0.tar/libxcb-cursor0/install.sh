apt install ./*.deb
